﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace ImageButton
{
    public class MyButton : Button
    {


        public ImageSource ImageFileA
        {
            get { return (ImageSource)GetValue(ImageFileAProperty); }
            set { SetValue(ImageFileAProperty, value); }
        }

        // Using a DependencyProperty as the backing store for ImageFileA.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty ImageFileAProperty =
            DependencyProperty.Register("ImageFileA", typeof(ImageSource), typeof(MyButton), new PropertyMetadata());



        public static ImageSource GetImageFile(DependencyObject obj)
        {
            return (ImageSource)obj.GetValue(ImageFileProperty);
        }

        public static void SetImageFile(DependencyObject obj, ImageSource value)
        {
            obj.SetValue(ImageFileProperty, value);
        }

        // Using a DependencyProperty as the backing store for ImageFile.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty ImageFileProperty =
            DependencyProperty.RegisterAttached("ImageFile", typeof(ImageSource), typeof(MyButton), new PropertyMetadata());


        //public static ImageSource GetImageFile(DependencyObject obj)
        //{
        //    return (ImageSource)obj.GetValue(ImageFileProperty);
        //}

        //public static void SetImageFile(DependencyObject obj, ImageSource value)
        //{
        //    obj.SetValue(ImageFileProperty, value);
        //}

        //// Using a DependencyProperty as the backing store for ImageFile.  This enables animation, styling, binding, etc...
        //public static readonly DependencyProperty ImageFileProperty =
        //    DependencyProperty.RegisterAttached("ImageFile", typeof(ImageSource), typeof(MyButton), new PropertyMetadata(""));


    }
}
